/*

The only thing stopping this from being used in older browsers is the "~" selector in the last CSS rule, but since replacing it results in messy code I left it as it is.

*/